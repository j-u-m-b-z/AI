import boto3
import os

def save_classification_result(result):
    """Save classification result to DynamoDB"""
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table(os.environ.get('TABLE_NAME'))
    
    item = {
        'ImageKey': result['image_id'],
        'SageMakerResult': result['sagemaker_result'],
        'RekognitionResult': result['rekognition_result'],
        'Agreement': result['agreement'],
        'Confidence': result['confidence']
    }
    
    if 'is_human' in result:
        item['IsHuman'] = result['is_human']
    
    table.put_item(Item=item)
    return True
